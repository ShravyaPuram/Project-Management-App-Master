import TeamPage from "@/components/team-page";

type Props = {};

function Page({}: Props) {
  return <TeamPage />;
}

export default Page;
