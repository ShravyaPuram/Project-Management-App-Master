import TimeLinePage from "@/components/timeline";
import React from "react";

type Props = {};

function Page({}: Props) {
  return <TimeLinePage />;
}

export default Page;
