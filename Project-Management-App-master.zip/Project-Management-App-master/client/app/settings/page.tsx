import SettingsPage from "@/components/settings-page";
import React from "react";

type Props = {};

function Page({}: Props) {
  return <SettingsPage />;
}

export default Page;
