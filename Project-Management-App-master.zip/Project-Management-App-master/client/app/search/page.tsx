import SearchPage from "@/components/search-page";

type Props = {};

function Page({}: Props) {
  return <SearchPage />;
}

export default Page;
