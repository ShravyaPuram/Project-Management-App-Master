import UserPage from "@/components/user-page";

type Props = {};

function Page({}: Props) {
  return <UserPage />;
}

export default Page;
