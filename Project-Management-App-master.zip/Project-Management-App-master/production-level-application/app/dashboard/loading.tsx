import { Spinner } from "@/components/global/loader/spinner";

type Props = {};

function Loading({}: Props) {
  return <Spinner />;
}

export default Loading;
